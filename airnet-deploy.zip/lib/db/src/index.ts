import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import * as schema from "./schema";

const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  min: 4, // Keep at least 4 authenticated connections warm for 0.1ms query dispatch
  max: 20,
  idleTimeoutMillis: 0, // Never drop idle pool connections
  connectionTimeoutMillis: 10000,
  keepAlive: true,
  keepAliveInitialDelayMillis: 10000,
});

// Resilient pool error listener: prevents Node crash if DB restarts or network resets
pool.on("error", (err) => {
  console.warn("[DB Pool] Idle client connection reset (auto-recovering):", err.message);
});

// Periodic TCP & NAT keepalive heartbeat ping every 25 seconds
const heartbeat = setInterval(() => {
  pool.query("SELECT 1").catch(() => {});
}, 25000);
if (heartbeat.unref) heartbeat.unref();

export const db = drizzle(pool, { schema });

export * from "./schema";
