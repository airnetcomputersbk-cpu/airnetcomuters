import { Router } from "express";
import { authMiddleware } from "../middlewares/auth";
import { 
  db, 
  servicesTable, 
  enquiriesTable, 
  applicationTasksTable, 
  recordsTable, 
  notificationsTable, 
  reportSettingsTable, 
  dailyReportLogsTable 
} from "@workspace/db";
import { eq, desc, asc, and, or, inArray, sql } from "drizzle-orm";
import { getCache, setCache, invalidateCache } from "../lib/cache";
import { broadcastEvent } from "../lib/events";
import fs from "fs";
import path from "path";
import { runOcrOnImage, extractNotificationDetails, normalizeDateToDMY } from "../lib/extractor";

export const adminRouter = Router();

adminRouter.post("/login", async (req, res) => {
  const { password } = req.body;
  const { getAdminMasterPassword } = await import("../lib/admin-auth-service");
  const masterPassword = await getAdminMasterPassword();
  if (password === masterPassword) {
    res.cookie("admin_session", password, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      maxAge: 1000 * 60 * 60 * 24, // 24 hours
    });
    res.json({ success: true });
  } else {
    res.status(401).json({ error: "Invalid password" });
  }
});

adminRouter.get("/me", async (req, res) => {
  const token = req.cookies?.admin_session;
  const { getAdminMasterPassword } = await import("../lib/admin-auth-service");
  const masterPassword = await getAdminMasterPassword();
  const authenticated = token === masterPassword;
  res.json({ authenticated });
});

adminRouter.post("/logout", (req, res) => {
  res.clearCookie("admin_session");
  res.json({ success: true });
});

// Public: Forgot Password - Send OTP to constant admin email (airnetcomputersbk@gmail.com)
adminRouter.post("/forgot-password/send-otp", async (req, res) => {
  try {
    const { generateAndSendAdminOtp } = await import("../lib/admin-auth-service");
    const result = await generateAndSendAdminOtp();
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || "Failed to send OTP" });
  }
});

// Public: Forgot Password - Verify OTP & Reset Password
adminRouter.post("/forgot-password/verify-reset", async (req, res) => {
  try {
    const { otp, newPassword } = req.body;
    const { verifyOtpAndResetPassword } = await import("../lib/admin-auth-service");
    const result = await verifyOtpAndResetPassword(otp, newPassword);
    if (result.success) {
      invalidateCache("admin:settings");
      res.cookie("admin_session", newPassword, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        maxAge: 1000 * 60 * 60 * 24, // 24 hours
      });
    }
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || "Failed to reset password" });
  }
});

// Public OAuth Callback redirect from Google (must be before authMiddleware so external redirect succeeds)
adminRouter.get("/gmail/callback", async (req, res) => {
  const frontendBase = process.env.FRONTEND_URL || "http://localhost:5000";
  try {
    const code = req.query.code as string;
    const error = req.query.error as string;

    if (error) {
      console.error("[admin] Google OAuth error in callback:", error);
      res.redirect(`${frontendBase}/admin/daily-reports?gmail_error=${encodeURIComponent(error)}`);
      return;
    }

    if (!code) {
      res.redirect(`${frontendBase}/admin/daily-reports?gmail_error=No_authorization_code_received`);
      return;
    }

    const { handleOAuthCallback } = await import("../lib/gmail-oauth-service");
    const origin = `${req.protocol}://${req.get("host")}`;
    const result = await handleOAuthCallback(code, origin);

    res.redirect(`${frontendBase}/admin/daily-reports?gmail_connected=true&email=${encodeURIComponent(result.email)}`);
  } catch (err: any) {
    console.error("[admin] Error handling Gmail OAuth callback:", err);
    res.redirect(`${frontendBase}/admin/daily-reports?gmail_error=${encodeURIComponent(err.message || "Failed to authorize account")}`);
  }
});

// Protected routes will go here
adminRouter.use(authMiddleware);

adminRouter.post("/services", async (req, res) => {
  try {
    const { eq } = await import("drizzle-orm");
    const serviceData = req.body || {};

    if (!serviceData.title || typeof serviceData.title !== "string" || !serviceData.title.trim()) {
      res.status(400).json({ error: "Service title is required." });
      return;
    }

    const cleanTitle = serviceData.title.trim();
    const cleanCategory = (serviceData.category && typeof serviceData.category === "string" && serviceData.category.trim()) || "Document Services";

    // Generate a clean slug-like base ID
    let baseId = cleanTitle
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "");

    if (!baseId) {
      baseId = `service-${Date.now()}`;
    }

    // Ensure unique ID in servicesTable to prevent primary key collision
    let finalId = baseId;
    let counter = 1;
    while (true) {
      const existing = await db
        .select({ id: servicesTable.id })
        .from(servicesTable)
        .where(eq(servicesTable.id, finalId));

      if (existing.length === 0) {
        break;
      }
      counter++;
      finalId = `${baseId}-${counter}`;
    }

    // Automatically ensure price has ₹ symbol
    let price = (serviceData.price || "").toString().trim();
    if (price && !price.startsWith("₹")) {
      const clean = price.replace(/^([₹\s]|rs\.?|inr)+/i, "").trim();
      price = clean ? `₹${clean}` : price;
    }

    // Determine logical orderIndex
    const allServices = await db.select({ orderIndex: servicesTable.orderIndex }).from(servicesTable);
    const maxOrder = allServices.reduce((max, s) => Math.max(max, s.orderIndex || 0), 0);
    const orderIndex = maxOrder + 1;

    // Category-specific authentic theme presets matching seed design exactly
    const categoryPresets: Record<string, { accent: string; icon: string }> = {
      "Identity": { accent: "bg-[#e5f0ea]", icon: "IdCard" },
      "Certificates": { accent: "bg-[#e6faee]", icon: "FileText" },
      "Online Applications": { accent: "bg-[#f5e6e6]", icon: "Briefcase" },
      "Document Services": { accent: "bg-[#e6f0fa]", icon: "BookOpen" },
      "Financial Services": { accent: "bg-[#e6faf6]", icon: "Banknote" },
      "Forms & payments": { accent: "bg-[#f4efe4]", icon: "Receipt" },
    };

    const preset = categoryPresets[cleanCategory] || { accent: "bg-[#e6f0fa]", icon: "FileText" };

    let finalAccent = serviceData.accent;
    if (!finalAccent || finalAccent === "bg-blue-500" || !finalAccent.startsWith("bg-[#")) {
      finalAccent = preset.accent;
    }

    let finalIcon = serviceData.icon;
    if (!finalIcon || finalIcon === "file-text" || finalIcon.includes("-")) {
      finalIcon = preset.icon;
    }

    const [newService] = await db
      .insert(servicesTable)
      .values({
        id: finalId,
        category: cleanCategory,
        title: cleanTitle,
        copy: (serviceData.copy && serviceData.copy.trim()) || "Available at Airnet Computers Online Service Center",
        price: price || "₹0",
        timing: (serviceData.timing && serviceData.timing.trim()) || "Varies",
        documents: (serviceData.documents && serviceData.documents.trim()) || "Please inquire at desk",
        icon: finalIcon,
        accent: finalAccent,
        isActive: serviceData.isActive !== false,
        orderIndex,
      })
      .returning();

    invalidateCache("services:*");
    broadcastEvent("services", "create", newService);
    res.json(newService);
  } catch (error: any) {
    console.error("[admin] Error creating service:", error);
    res.status(500).json({ error: error.message || "Failed to create service" });
  }
});

adminRouter.delete("/services/:id", async (req, res) => {
  try {
    await db.delete(servicesTable).where(eq(servicesTable.id, req.params.id));
    invalidateCache("services:*");
    broadcastEvent("services", "delete", { id: req.params.id });
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: "Failed to delete service" });
  }
});

adminRouter.patch("/services/:id", async (req, res) => {
  try {
    const { id, ...updateData } = req.body;

    if (updateData.price) {
      let price = updateData.price.toString().trim();
      if (price && !price.startsWith("₹")) {
        const clean = price.replace(/^([₹\s]|rs\.?|inr)+/i, "").trim();
        updateData.price = clean ? `₹${clean}` : price;
      }
    }

    const categoryPresets: Record<string, { accent: string; icon: string }> = {
      "Identity": { accent: "bg-[#e5f0ea]", icon: "IdCard" },
      "Certificates": { accent: "bg-[#e6faee]", icon: "FileText" },
      "Online Applications": { accent: "bg-[#f5e6e6]", icon: "Briefcase" },
      "Document Services": { accent: "bg-[#e6f0fa]", icon: "BookOpen" },
      "Financial Services": { accent: "bg-[#e6faf6]", icon: "Banknote" },
      "Forms & payments": { accent: "bg-[#f4efe4]", icon: "Receipt" },
    };

    if (updateData.category && categoryPresets[updateData.category]) {
      const preset = categoryPresets[updateData.category];
      if (!updateData.accent || updateData.accent === "bg-blue-500" || !updateData.accent.startsWith("bg-[#")) {
        updateData.accent = preset.accent;
      }
      if (!updateData.icon || updateData.icon === "file-text" || updateData.icon.includes("-")) {
        updateData.icon = preset.icon;
      }
    }
    
    const [updatedService] = await db.update(servicesTable)
      .set(updateData)
      .where(eq(servicesTable.id, req.params.id))
      .returning();
      
    invalidateCache("services:*");
    broadcastEvent("services", "update", updatedService);
    res.json(updatedService);
  } catch (error) {
    console.error("Failed to update service:", error);
    res.status(500).json({ error: "Failed to update service" });
  }
});

adminRouter.get("/enquiries", async (req, res) => {
  try {
    const cached = getCache<any[]>("admin:enquiries");
    if (cached) {
      res.setHeader("X-Cache", "HIT");
      return res.json(cached);
    }
    
    // Execute all 3 queries concurrently in parallel
    const [allEnquiries, allTasks, allServices] = await Promise.all([
      db.select().from(enquiriesTable).orderBy(desc(enquiriesTable.createdAt)),
      db.select({
        customerId: applicationTasksTable.customerId,
        status: applicationTasksTable.status,
        progressPercent: applicationTasksTable.progressPercent,
        currentStep: applicationTasksTable.currentStep,
        steps: applicationTasksTable.steps,
      }).from(applicationTasksTable),
      db.select({
        id: servicesTable.id,
        title: servicesTable.title,
      }).from(servicesTable),
    ]);
    
    const taskMap = new Map<string, any>();
    allTasks.forEach(t => {
      if (t.customerId) taskMap.set(t.customerId, t);
    });

    const serviceMap = new Map<string, string>();
    allServices.forEach(s => {
      serviceMap.set(s.id, s.title);
    });

    const enriched = allEnquiries.map(enq => {
      const task = enq.customerId ? taskMap.get(enq.customerId) : null;
      let serviceTitle = enq.serviceId ? serviceMap.get(enq.serviceId) || enq.serviceId : "";
      if (!serviceTitle && enq.notes) {
        const m = enq.notes.match(/Requested Service:\s*([^\n\r]+)/);
        if (m && m[1]) serviceTitle = m[1].trim();
      }
      if (!serviceTitle) serviceTitle = "General Online Service Enquiry";

      const isCompleted = enq.applicationStatus === "Completed" || task?.status === "Completed";
      const progressPercent = task?.progressPercent ?? (isCompleted ? 100 : enq.applicationStatus === "Accepted" ? 40 : enq.applicationStatus === "On Hold" ? 25 : 15);
      const currentStep = task?.currentStep ?? (isCompleted 
        ? "Application Completed & Ready" 
        : enq.applicationStatus === "Accepted" 
        ? "Accepted & In Progress" 
        : enq.applicationStatus === "On Hold"
        ? "On Hold for Verification"
        : "Enquiry Received");

      return {
        ...enq,
        serviceTitle,
        progressPercent,
        currentStep,
        taskStatus: task?.status || enq.applicationStatus,
        steps: task?.steps || [],
      };
    });

    setCache("admin:enquiries", enriched, 3600);
    res.setHeader("X-Cache", "MISS");
    res.json(enriched);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch enquiries" });
  }
});

adminRouter.patch("/enquiries/:id", async (req, res) => {
  try {
    const { syncToTracker, ...allowedFields } = req.body;
    const updateData: Record<string, any> = { ...allowedFields, updatedAt: new Date() };

    if (updateData.amountCharged !== undefined) {
      updateData.amountCharged = Number(updateData.amountCharged) || 0;
    }
    if (updateData.amountPaid !== undefined) {
      updateData.amountPaid = Number(updateData.amountPaid) || 0;
    }
    if (updateData.amountPending !== undefined) {
      updateData.amountPending = Number(updateData.amountPending) || 0;
    } else if (updateData.amountCharged !== undefined && updateData.amountPaid !== undefined) {
      updateData.amountPending = Math.max(0, (Number(updateData.amountCharged) || 0) - updateData.amountPaid);
    }

    const [updatedEnquiry] = await db.update(enquiriesTable)
      .set(updateData)
      .where(eq(enquiriesTable.id, Number(req.params.id)))
      .returning();

    const isAccepted = updatedEnquiry.applicationStatus === "Accepted" || req.body.applicationStatus === "Accepted";
    const isCompleted = updatedEnquiry.applicationStatus === "Completed" || req.body.applicationStatus === "Completed";

    // If saving to ledger, or marked Accepted or Completed, sync into application_tasks and records tables
    if (syncToTracker || req.body.syncToTracker || isAccepted || isCompleted) {
      try {
        let effectiveCustomerId = updatedEnquiry.customerId;
        if (!effectiveCustomerId) {
          effectiveCustomerId = `AN-${Math.floor(10000 + Math.random() * 90000)}`;
          await db.update(enquiriesTable).set({ customerId: effectiveCustomerId }).where(eq(enquiriesTable.id, updatedEnquiry.id));
          updatedEnquiry.customerId = effectiveCustomerId;
        }

        let serviceTitle = "";
        if (updatedEnquiry.serviceId) {
          const matchedService = await db.select({ title: servicesTable.title }).from(servicesTable).where(eq(servicesTable.id, updatedEnquiry.serviceId));
          if (matchedService.length > 0 && matchedService[0].title) {
            serviceTitle = matchedService[0].title;
          } else {
            serviceTitle = updatedEnquiry.serviceId;
          }
        }
        if (!serviceTitle && updatedEnquiry.notes) {
          const match = updatedEnquiry.notes.match(/Requested Service:\s*([^\n\r]+)/);
          if (match && match[1]) serviceTitle = match[1].trim();
        }
        if (!serviceTitle) serviceTitle = "General Service";

        const charged = updatedEnquiry.amountCharged ?? 0;
        const paid = updatedEnquiry.amountPaid ?? 0;
        const pending = updatedEnquiry.amountPending ?? Math.max(0, charged - paid);

        // Check if an application task exists for this customer
        const existingTasks = await db.select().from(applicationTasksTable)
          .where(eq(applicationTasksTable.customerId, effectiveCustomerId));

        const lowerService = serviceTitle.toLowerCase();
        let defaultSteps = [
          { id: "step-1", title: "Application & Documents Received", status: "completed", completedAt: new Date().toISOString(), note: "Application received and verified from enquiry" },
          { id: "step-2", title: "Data Entry & Portal Submission", status: isCompleted ? "completed" : "in-progress", completedAt: isCompleted ? new Date().toISOString() : null, note: "Processing application online" },
          { id: "step-3", title: "Official Department Verification", status: isCompleted ? "completed" : "pending", completedAt: isCompleted ? new Date().toISOString() : null, note: "" },
          { id: "step-4", title: "Approval & Document Generation", status: isCompleted ? "completed" : "pending", completedAt: isCompleted ? new Date().toISOString() : null, note: "" },
          { id: "step-5", title: "Print & Delivery to Customer", status: isCompleted ? "completed" : "pending", completedAt: isCompleted ? new Date().toISOString() : null, note: "" },
        ];

        if (lowerService.includes("pan")) {
          defaultSteps = [
            { id: "step-1", title: "Proof of Identity & Address Verified", status: "completed", completedAt: new Date().toISOString(), note: "Documents collected and verified" },
            { id: "step-2", title: "Application Uploaded & Acknowledgment Generated", status: isCompleted ? "completed" : "in-progress", completedAt: isCompleted ? new Date().toISOString() : null, note: "Online submission on portal" },
            { id: "step-3", title: "Document Verification by NSDL / UTIITSL", status: isCompleted ? "completed" : "pending", completedAt: isCompleted ? new Date().toISOString() : null, note: "" },
            { id: "step-4", title: "e-PAN Generated & Sent via Email", status: isCompleted ? "completed" : "pending", completedAt: isCompleted ? new Date().toISOString() : null, note: "" },
            { id: "step-5", title: "Physical Card Printed & Delivered", status: isCompleted ? "completed" : "pending", completedAt: isCompleted ? new Date().toISOString() : null, note: "" },
          ];
        } else if (lowerService.includes("aadhaar")) {
          defaultSteps = [
            { id: "step-1", title: "Enrolment / Update Form Filled", status: "completed", completedAt: new Date().toISOString(), note: "Data entry completed" },
            { id: "step-2", title: "Biometrics & Demographic Data Uploaded", status: isCompleted ? "completed" : "in-progress", completedAt: isCompleted ? new Date().toISOString() : null, note: "Data processed with UIDAI portal" },
            { id: "step-3", title: "Backend Verification by UIDAI", status: isCompleted ? "completed" : "pending", completedAt: isCompleted ? new Date().toISOString() : null, note: "" },
            { id: "step-4", title: "Updated Aadhaar Card Downloaded & Printed", status: isCompleted ? "completed" : "pending", completedAt: isCompleted ? new Date().toISOString() : null, note: "" },
          ];
        } else if (lowerService.includes("passport")) {
          defaultSteps = [
            { id: "step-1", title: "Documents Collected & Scrutiny Done", status: "completed", completedAt: new Date().toISOString(), note: "Document scrutiny complete" },
            { id: "step-2", title: "Online Form Submission & Fee Paid", status: isCompleted ? "completed" : "in-progress", completedAt: isCompleted ? new Date().toISOString() : null, note: "Portal application submitted" },
            { id: "step-3", title: "Appointment Scheduled at PSK / POPSK", status: isCompleted ? "completed" : "pending", completedAt: isCompleted ? new Date().toISOString() : null, note: "" },
            { id: "step-4", title: "Police Verification & Clearance", status: isCompleted ? "completed" : "pending", completedAt: isCompleted ? new Date().toISOString() : null, note: "" },
            { id: "step-5", title: "Passport Printed & Dispatched", status: isCompleted ? "completed" : "pending", completedAt: isCompleted ? new Date().toISOString() : null, note: "" },
            { id: "step-6", title: "Passport Received & Handed to Customer", status: isCompleted ? "completed" : "pending", completedAt: isCompleted ? new Date().toISOString() : null, note: "" },
          ];
        }

        const targetStatus = isCompleted ? "Completed" : "In Progress";
        const targetProgress = isCompleted ? 100 : Math.round((1 / defaultSteps.length) * 100);
        const targetStep = isCompleted 
          ? "Application Completed & Saved to Records" 
          : (existingTasks[0]?.currentStep || defaultSteps[1]?.title || "Application & Documents Received");

        let taskResult = null;
        if (existingTasks.length > 0) {
          const [updatedTask] = await db.update(applicationTasksTable)
            .set({
              customerName: updatedEnquiry.customerName,
              mobileNumber: updatedEnquiry.mobileNumber,
              serviceName: serviceTitle || existingTasks[0].serviceName,
              paymentType: updatedEnquiry.paymentMethod || "Cash",
              amountPaid: paid,
              amountPending: pending,
              status: targetStatus,
              progressPercent: targetProgress,
              currentStep: targetStep,
              updatedAt: new Date(),
            })
            .where(eq(applicationTasksTable.id, existingTasks[0].id))
            .returning();
          taskResult = updatedTask;
        } else {
          const [newTask] = await db.insert(applicationTasksTable).values({
            customerId: effectiveCustomerId,
            customerName: updatedEnquiry.customerName,
            mobileNumber: updatedEnquiry.mobileNumber,
            serviceName: serviceTitle,
            applicationNumber: `APP-${effectiveCustomerId}`,
            currentStep: targetStep,
            status: targetStatus,
            progressPercent: targetProgress,
            steps: defaultSteps,
            priority: "Normal",
            paymentType: updatedEnquiry.paymentMethod || "Cash",
            amountPaid: paid,
            amountPending: pending,
            notes: updatedEnquiry.notes || (isAccepted ? "Accepted from Customer Enquiry" : "Recorded from Enquiry Ledger"),
          }).returning();
          taskResult = newTask;
        }

        // Add or update into records table if completed or saving to ledger
        if (isCompleted || syncToTracker || req.body.syncToTracker) {
          const existingRecords = await db.select().from(recordsTable)
            .where(eq(recordsTable.customerId, effectiveCustomerId));
          if (existingRecords.length > 0) {
            await db.update(recordsTable)
              .set({
                customerName: updatedEnquiry.customerName,
                mobileNumber: updatedEnquiry.mobileNumber,
                serviceProvided: serviceTitle || existingRecords[0].serviceProvided,
                amountCharged: charged,
                amountPaid: paid,
                amountPending: pending,
                paymentMethod: updatedEnquiry.paymentMethod || "Cash",
                notes: updatedEnquiry.notes || existingRecords[0].notes,
              })
              .where(eq(recordsTable.id, existingRecords[0].id));
          } else {
            await db.insert(recordsTable).values({
              customerId: effectiveCustomerId,
              customerName: updatedEnquiry.customerName,
              mobileNumber: updatedEnquiry.mobileNumber,
              serviceProvided: serviceTitle,
              amountCharged: charged,
              amountPaid: paid,
              amountPending: pending,
              paymentMethod: updatedEnquiry.paymentMethod || "Cash",
              notes: updatedEnquiry.notes || "",
            });
          }
        }
      } catch (syncErr) {
        console.error("Error syncing enquiry to tracker/records:", syncErr);
      }
    }
      
    invalidateCache("admin:enquiries");
    invalidateCache("admin:tracker");
    invalidateCache("admin:records");
    broadcastEvent("enquiries", "update", updatedEnquiry);
    if (isAccepted || isCompleted || syncToTracker || req.body.syncToTracker) {
      broadcastEvent("tracker", "update");
      broadcastEvent("records", "update");
    }
    res.json({
      ...updatedEnquiry,
      movedToTracker: Boolean(isAccepted || isCompleted || syncToTracker),
      trackingId: updatedEnquiry.customerId,
    });
  } catch (error) {
    console.error("Failed to update enquiry:", error);
    res.status(500).json({ error: "Failed to update enquiry" });
  }
});

adminRouter.delete("/enquiries/:id", async (req, res) => {
  try {
    const enqId = Number(req.params.id);
    const existing = await db.select().from(enquiriesTable).where(eq(enquiriesTable.id, enqId));
    if (existing.length > 0 && existing[0].customerId) {
      // Also delete any tracker tasks associated with this rejected/deleted enquiry
      await db.delete(applicationTasksTable).where(eq(applicationTasksTable.customerId, existing[0].customerId));
    }

    await db.delete(enquiriesTable).where(eq(enquiriesTable.id, enqId));
    invalidateCache("admin:enquiries");
    invalidateCache("admin:tracker");
    broadcastEvent("enquiries", "delete", { id: enqId, customerId: existing[0]?.customerId });
    broadcastEvent("tracker", "delete", { customerId: existing[0]?.customerId });
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: "Failed to delete enquiry" });
  }
});

adminRouter.post("/enquiries", async (req, res) => {
  try {
    const randomDigits = Math.floor(10000 + Math.random() * 90000);
    const customerId = req.body.customerId || `AN-${randomDigits}`;

    const charged = Number(req.body.amountCharged) || 0;
    const paid = req.body.amountPaid !== undefined ? Number(req.body.amountPaid) || 0 : 0;
    const pending = req.body.amountPending !== undefined ? Number(req.body.amountPending) || 0 : Math.max(0, charged - paid);

    let finalServiceId: string | null = null;
    let finalNotes = req.body.notes || "";

    if (req.body.serviceId) {
      const existingService = await db.select().from(servicesTable).where(eq(servicesTable.id, req.body.serviceId));
      if (existingService.length > 0) {
        finalServiceId = req.body.serviceId;
      } else {
        const matchingServices = await db.select().from(servicesTable).where(eq(servicesTable.title, req.body.serviceId));
        if (matchingServices.length > 0) {
          finalServiceId = matchingServices[0].id;
        } else {
          finalNotes = `Requested Service: ${req.body.serviceId}\n\n${finalNotes}`;
        }
      }
    }

    const { serviceId, notes, ...otherFields } = req.body;

    const [newEnquiry] = await db.insert(enquiriesTable).values({
      ...otherFields,
      customerId,
      serviceId: finalServiceId,
      notes: finalNotes,
      amountCharged: charged,
      amountPaid: paid,
      amountPending: pending,
    }).returning();
    
    invalidateCache("admin:enquiries");
    broadcastEvent("enquiries", "create", newEnquiry);
    res.json(newEnquiry);
  } catch (error) {
    console.error("Error creating enquiry:", error);
    res.status(500).json({ error: "Failed to add manual record" });
  }
});

adminRouter.post("/enquiries/bulk-delete", async (req, res) => {
  try {
    const { ids } = req.body;
    
    if (!ids || !Array.isArray(ids) || ids.length === 0) {
      res.status(400).json({ error: "No IDs provided" });
      return;
    }
    
    await db.delete(enquiriesTable).where(inArray(enquiriesTable.id, ids));
    invalidateCache("admin:enquiries");
    broadcastEvent("enquiries", "bulk_delete", { ids });
    res.json({ success: true, deletedCount: ids.length });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to bulk delete records" });
  }
});

adminRouter.get("/records", async (req, res) => {
  try {
    const cached = getCache<any[]>("admin:records");
    if (cached) {
      res.setHeader("X-Cache", "HIT");
      return res.json(cached);
    }
    const allRecords = await db.select().from(recordsTable).orderBy(desc(recordsTable.createdAt));
    setCache("admin:records", allRecords, 3600);
    res.setHeader("X-Cache", "MISS");
    res.json(allRecords);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch records" });
  }
});

adminRouter.post("/records", async (req, res) => {
  try {
    let { customerId, customerName, mobileNumber, serviceProvided, amountCharged, amountPaid, amountPending, paymentMethod, notes } = req.body;
    
    // Auto-generate Customer ID if not provided
    if (!customerId) {
      const randomDigits = Math.floor(10000 + Math.random() * 90000); // 5 digit random number
      customerId = `AN-${randomDigits}`;
    }

    const charged = amountCharged !== undefined ? Number(amountCharged) || 0 : ((Number(amountPaid) || 0) + (Number(amountPending) || 0));
    const paid = amountPaid !== undefined ? Number(amountPaid) || 0 : 0;
    const pending = amountPending !== undefined ? Number(amountPending) || 0 : Math.max(0, charged - paid);

    const [newRecord] = await db.insert(recordsTable).values({
      customerId,
      customerName,
      mobileNumber,
      serviceProvided,
      amountCharged: charged,
      amountPaid: paid,
      amountPending: pending,
      paymentMethod: paymentMethod || "Cash",
      notes,
    }).returning();

    invalidateCache("admin:records");
    broadcastEvent("records", "create", newRecord);
    res.json(newRecord);
  } catch (error) {
    console.error("Error creating record:", error);
    res.status(500).json({ error: "Failed to create record" });
  }
});

adminRouter.patch("/records/:id", async (req, res) => {
  try {
    const updateData: Record<string, any> = { ...req.body };
    if (updateData.amountCharged !== undefined) updateData.amountCharged = Number(updateData.amountCharged) || 0;
    if (updateData.amountPaid !== undefined) updateData.amountPaid = Number(updateData.amountPaid) || 0;
    if (updateData.amountPending !== undefined) updateData.amountPending = Number(updateData.amountPending) || 0;

    const [updatedRecord] = await db.update(recordsTable)
      .set(updateData)
      .where(eq(recordsTable.id, Number(req.params.id)))
      .returning();
      
    invalidateCache("admin:records");
    broadcastEvent("records", "update", updatedRecord);
    res.json(updatedRecord);
  } catch (error) {
    res.status(500).json({ error: "Failed to update record" });
  }
});

adminRouter.delete("/records/:id", async (req, res) => {
  try {
    const recId = Number(req.params.id);
    await db.delete(recordsTable).where(eq(recordsTable.id, recId));
    invalidateCache("admin:records");
    broadcastEvent("records", "delete", { id: recId });
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: "Failed to delete record" });
  }
});

// ================= APPLICATION TRACKER ROUTES =================

adminRouter.get("/tracker", async (req, res) => {
  try {
    const cached = getCache<any[]>("admin:tracker");
    if (cached) {
      res.setHeader("X-Cache", "HIT");
      return res.json(cached);
    }
    const tasks = await db.select().from(applicationTasksTable).orderBy(desc(applicationTasksTable.createdAt));
    setCache("admin:tracker", tasks, 3600);
    res.setHeader("X-Cache", "MISS");
    res.json(tasks);
  } catch (error) {
    console.error("Error fetching application tasks:", error);
    res.status(500).json({ error: "Failed to fetch application tasks" });
  }
});

adminRouter.post("/tracker", async (req, res) => {
  try {
    let {
      customerId,
      customerName,
      mobileNumber,
      serviceName,
      applicationNumber,
      steps,
      currentStep,
      status,
      progressPercent,
      priority,
      targetDate,
      assignedStaff,
      paymentType,
      amountPaid,
      amountPending,
      notes,
    } = req.body;

    if (!customerId) {
      const randomDigits = Math.floor(10000 + Math.random() * 90000);
      customerId = `AN-${randomDigits}`;
    }

    if (!steps || !Array.isArray(steps) || steps.length === 0) {
      steps = [
        { id: "step-1", title: "Application & Documents Received", status: "completed", completedAt: new Date().toISOString(), note: "Documents collected and verified" },
        { id: "step-2", title: "Data Entry & Portal Submission", status: "in-progress", completedAt: null, note: "Processing application online" },
        { id: "step-3", title: "Official Department Verification", status: "pending", completedAt: null, note: "" },
        { id: "step-4", title: "Approval & Document Generation", status: "pending", completedAt: null, note: "" },
        { id: "step-5", title: "Print & Delivery to Customer", status: "pending", completedAt: null, note: "" },
      ];
    }

    if (progressPercent === undefined || progressPercent === null) {
      const completedSteps = steps.filter((s: any) => s.status === "completed").length;
      progressPercent = Math.round((completedSteps / steps.length) * 100);
    }

    if (!currentStep) {
      const activeStep = steps.find((s: any) => s.status === "in-progress") || steps.find((s: any) => s.status === "pending") || steps[steps.length - 1];
      currentStep = activeStep ? activeStep.title : "Application Received";
    }

    const paid = Number(amountPaid) || 0;
    const pending = amountPending !== undefined 
      ? Number(amountPending) || 0 
      : (req.body.amountCharged !== undefined ? Math.max(0, (Number(req.body.amountCharged) || 0) - paid) : 0);

    const [newTask] = await db.insert(applicationTasksTable).values({
      customerId,
      customerName,
      mobileNumber,
      serviceName,
      applicationNumber: applicationNumber || "",
      currentStep,
      status: status || "In Progress",
      progressPercent: Number(progressPercent) || 20,
      steps,
      priority: priority || "Normal",
      targetDate: targetDate || "",
      assignedStaff: assignedStaff || "",
      paymentType: paymentType || "Cash",
      amountPaid: paid,
      amountPending: pending,
      notes: notes || "",
    }).returning();

    invalidateCache("admin:tracker");
    invalidateCache("admin:enquiries");
    broadcastEvent("tracker", "create", newTask);
    broadcastEvent("enquiries", "update");
    res.json(newTask);
  } catch (error) {
    console.error("Error creating application task:", error);
    res.status(500).json({ error: "Failed to create application task" });
  }
});

adminRouter.patch("/tracker/:id", async (req, res) => {
  try {
    const { id, createdAt, ...allowedFields } = req.body;
    const updateData: Record<string, any> = {
      ...allowedFields,
      updatedAt: new Date(),
    };

    if (updateData.amountPaid !== undefined) {
      updateData.amountPaid = Number(updateData.amountPaid) || 0;
    }
    if (updateData.amountPending !== undefined) {
      updateData.amountPending = Number(updateData.amountPending) || 0;
    } else if (updateData.amountCharged !== undefined && updateData.amountPaid !== undefined) {
      updateData.amountPending = Math.max(0, (Number(updateData.amountCharged) || 0) - updateData.amountPaid);
    }

    if (updateData.steps && Array.isArray(updateData.steps)) {
      if (updateData.progressPercent === undefined) {
        const completedCount = updateData.steps.filter((s: any) => s.status === "completed").length;
        updateData.progressPercent = Math.round((completedCount / updateData.steps.length) * 100);
      }
      if (!updateData.currentStep) {
        const inProgress = updateData.steps.find((s: any) => s.status === "in-progress");
        const pending = updateData.steps.find((s: any) => s.status === "pending");
        if (inProgress) updateData.currentStep = inProgress.title;
        else if (pending) updateData.currentStep = pending.title;
        else if (updateData.steps.length > 0) updateData.currentStep = updateData.steps[updateData.steps.length - 1].title;
      }
    }

    const [updatedTask] = await db.update(applicationTasksTable)
      .set(updateData)
      .where(eq(applicationTasksTable.id, Number(req.params.id)))
      .returning();

    invalidateCache("admin:tracker");
    invalidateCache("admin:enquiries");
    broadcastEvent("tracker", "update", updatedTask);
    broadcastEvent("enquiries", "update");
    res.json(updatedTask);
  } catch (error) {
    console.error("Error updating application task:", error);
    res.status(500).json({ error: "Failed to update application task" });
  }
});

adminRouter.delete("/tracker/:id", async (req, res) => {
  try {
    const taskId = Number(req.params.id);
    await db.delete(applicationTasksTable).where(eq(applicationTasksTable.id, taskId));
    invalidateCache("admin:tracker");
    invalidateCache("admin:enquiries");
    broadcastEvent("tracker", "delete", { id: taskId });
    broadcastEvent("enquiries", "update");
    res.json({ success: true });
  } catch (error) {
    console.error("Error deleting application task:", error);
    res.status(500).json({ error: "Failed to delete application task" });
  }
});

// Upload poster / document with OCR text reading and intelligent metadata extraction
adminRouter.post("/notifications/upload", async (req, res) => {
  try {
    const { fileName, fileData, rawText, category } = req.body || {};
    
    let fileUrl = "";
    let ocrText = rawText || "";

    if (fileData) {
      const uploadsDir = path.resolve(process.cwd(), "artifacts/api-server/uploads");
      if (!fs.existsSync(uploadsDir)) {
        fs.mkdirSync(uploadsDir, { recursive: true });
      }

      // Extract raw base64 and mime
      const matches = fileData.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
      let buffer: Buffer;
      let ext = ".jpg";

      if (matches && matches.length === 3) {
        const mime = matches[1];
        buffer = Buffer.from(matches[2], "base64");
        if (mime.includes("pdf")) ext = ".pdf";
        else if (mime.includes("jpeg") || mime.includes("jpg")) ext = ".jpg";
        else if (mime.includes("png")) ext = ".png";
        else if (mime.includes("webp")) ext = ".webp";
      } else {
        buffer = Buffer.from(fileData, "base64");
        if (fileName && fileName.includes(".")) {
          ext = path.extname(fileName);
        }
      }

      const safeName = `poster_${Date.now()}_${Math.floor(Math.random() * 1000)}${ext}`;
      const filePath = path.join(uploadsDir, safeName);
      fs.writeFileSync(filePath, buffer);
      fileUrl = `/uploads/${safeName}`;

      // If document is an image and no rawText provided, run OCR to extract actual poster text
      if (!ocrText && /\.(jpg|jpeg|png|webp)$/i.test(safeName)) {
        console.log(`[OCR] Scanning uploaded poster: ${filePath}`);
        ocrText = await runOcrOnImage(filePath);
        console.log(`[OCR] Recognition completed. Extracted ${ocrText.length} characters.`);
      }
    }

    // Auto extract metadata using OCR text & pattern recognition
    const extractedData = extractNotificationDetails(fileName || "Notification Poster", ocrText, category);

    res.json({
      success: true,
      fileUrl,
      extractedData,
      ocrPreview: ocrText.slice(0, 300),
    });
  } catch (error) {
    console.error("Error uploading notification document:", error);
    res.status(500).json({ error: "Failed to process uploaded document" });
  }
});

// Notifications CRUD for Admin
adminRouter.get("/notifications", async (req, res) => {
  try {
    const cached = getCache<any[]>("admin:notifications");
    if (cached) {
      res.setHeader("X-Cache", "HIT");
      return res.json(cached);
    }

    const notifications = await db
      .select()
      .from(notificationsTable)
      .orderBy(desc(notificationsTable.createdAt));

    const formatted = notifications.map(n => ({
      ...n,
      startDate: normalizeDateToDMY(n.startDate) || n.startDate,
      lastDate: normalizeDateToDMY(n.lastDate) || n.lastDate,
    }));

    setCache("admin:notifications", formatted, 3600);
    res.setHeader("X-Cache", "MISS");
    res.json(formatted);
  } catch (error) {
    console.error("Error fetching admin notifications:", error);
    res.status(500).json({ error: "Failed to fetch notifications" });
  }
});

adminRouter.post("/notifications", async (req, res) => {
  try {
    const notificationData = req.body;

    const [created] = await db.insert(notificationsTable).values({
      title: notificationData.title,
      organization: notificationData.organization || "",
      category: notificationData.category || "Govt Jobs",
      vacancies: notificationData.vacancies || "",
      qualification: notificationData.qualification || "",
      ageLimit: notificationData.ageLimit || "",
      startDate: normalizeDateToDMY(notificationData.startDate) || notificationData.startDate || "",
      lastDate: normalizeDateToDMY(notificationData.lastDate) || notificationData.lastDate || "",
      applicationFee: notificationData.applicationFee || "",
      posterUrl: notificationData.posterUrl || "",
      attachmentUrl: notificationData.attachmentUrl || "",
      applyUrl: notificationData.applyUrl || "",
      description: notificationData.description || "",
      isFeatured: Boolean(notificationData.isFeatured),
      status: notificationData.status || "Published",
      viewCount: 0,
    }).returning();

    invalidateCache("admin:notifications");
    invalidateCache("notifications:*");
    broadcastEvent("notifications", "create", created);
    res.json(created);
  } catch (error) {
    console.error("Error creating notification:", error);
    res.status(500).json({ error: "Failed to create notification" });
  }
});

adminRouter.patch("/notifications/:id", async (req, res) => {
  try {
    const { id, createdAt, ...updateData } = req.body;

    if (updateData.startDate !== undefined) {
      updateData.startDate = normalizeDateToDMY(updateData.startDate) || updateData.startDate;
    }
    if (updateData.lastDate !== undefined) {
      updateData.lastDate = normalizeDateToDMY(updateData.lastDate) || updateData.lastDate;
    }

    updateData.updatedAt = new Date();

    const [updated] = await db
      .update(notificationsTable)
      .set(updateData)
      .where(eq(notificationsTable.id, Number(req.params.id)))
      .returning();

    invalidateCache("admin:notifications");
    invalidateCache("notifications:*");
    broadcastEvent("notifications", "update", updated);
    res.json(updated);
  } catch (error) {
    console.error("Error updating notification:", error);
    res.status(500).json({ error: "Failed to update notification" });
  }
});

adminRouter.delete("/notifications/:id", async (req, res) => {
  try {
    const notifId = Number(req.params.id);
    await db
      .delete(notificationsTable)
      .where(eq(notificationsTable.id, notifId));

    invalidateCache("admin:notifications");
    invalidateCache("notifications:*");
    broadcastEvent("notifications", "delete", { id: notifId });
    res.json({ success: true });
  } catch (error) {
    console.error("Error deleting notification:", error);
    res.status(500).json({ error: "Failed to delete notification" });
  }
});

// ==============================================================
// DATA BACKUP & MANAGEMENT ENDPOINTS
// ==============================================================

// 1. Full System Disaster Recovery Snapshot (All Tables in JSON)
adminRouter.get("/backup/full", async (req, res) => {
  try {
    const { db, servicesTable, enquiriesTable, recordsTable, applicationTasksTable, notificationsTable } = await import("@workspace/db");
    const { getAdminMobileNumber } = await import("../lib/admin-auth-service");
    const activeAdminPhone = await getAdminMobileNumber();

    const [services, enquiries, records, applicationTasks, notifications] = await Promise.all([
      db.select().from(servicesTable),
      db.select().from(enquiriesTable),
      db.select().from(recordsTable),
      db.select().from(applicationTasksTable),
      db.select().from(notificationsTable),
    ]);

    const backupPayload = {
      metadata: {
        centerName: "Airnet Computers Online Service Center",
        location: "Opp. Congress Office, Near Omer Masjid, Haralayya Chowk, Basavakalyan – 585327",
        owner: `Md Amjad Ali (${activeAdminPhone})`,
        exportedAt: new Date().toISOString(),
        version: "2.0",
        counts: {
          services: services.length,
          enquiries: enquiries.length,
          records: records.length,
          applicationTasks: applicationTasks.length,
          notifications: notifications.length,
          total: services.length + enquiries.length + records.length + applicationTasks.length + notifications.length
        }
      },
      services,
      enquiries,
      records,
      applicationTasks,
      notifications
    };

    res.json(backupPayload);
  } catch (error) {
    console.error("Error creating full backup snapshot:", error);
    res.status(500).json({ error: "Failed to generate system backup snapshot" });
  }
});

// 2. Safe Database Restore / Import Endpoint
adminRouter.post("/backup/restore", async (req, res) => {
  try {
    const { db, servicesTable, enquiriesTable, applicationTasksTable, notificationsTable } = await import("@workspace/db");
    const { eq } = await import("drizzle-orm");
    const { payload } = req.body || {};

    if (!payload || !payload.metadata) {
      res.status(400).json({ error: "Invalid backup file structure or missing metadata" });
      return;
    }

    const restoredCounts = {
      services: 0,
      enquiries: 0,
      applicationTasks: 0,
      notifications: 0
    };

    // Restore Services (Safe insert if not exists)
    if (Array.isArray(payload.services) && payload.services.length > 0) {
      for (const s of payload.services) {
        if (s.id && s.title) {
          const existing = await db.select().from(servicesTable).where(eq(servicesTable.id, s.id));
          if (existing.length === 0) {
            await db.insert(servicesTable).values({
              id: s.id,
              category: s.category || "General",
              title: s.title,
              copy: s.copy || "",
              timing: s.timing || "Varies",
              price: s.price || "₹0",
              documents: s.documents || "Inquire",
              icon: s.icon || "file-text",
              accent: s.accent || "bg-blue-500",
              isActive: s.isActive ?? true,
              orderIndex: s.orderIndex || 0,
            });
            restoredCounts.services++;
          }
        }
      }
    }

    // Restore Notifications
    if (Array.isArray(payload.notifications) && payload.notifications.length > 0) {
      for (const n of payload.notifications) {
        if (n.title && n.category) {
          await db.insert(notificationsTable).values({
            title: n.title,
            organization: n.organization || null,
            category: n.category,
            vacancies: n.vacancies || null,
            qualification: n.qualification || null,
            ageLimit: n.ageLimit || null,
            startDate: n.startDate || null,
            lastDate: n.lastDate || null,
            applicationFee: n.applicationFee || null,
            posterUrl: n.posterUrl || null,
            attachmentUrl: n.attachmentUrl || null,
            applyUrl: n.applyUrl || null,
            description: n.description || null,
            isFeatured: n.isFeatured ?? false,
            status: n.status || "Published",
            viewCount: n.viewCount || 0
          });
          restoredCounts.notifications++;
        }
      }
    }

    // Restore Application Tasks
    if (Array.isArray(payload.applicationTasks) && payload.applicationTasks.length > 0) {
      for (const t of payload.applicationTasks) {
        if (t.customerId && t.customerName) {
          await db.insert(applicationTasksTable).values({
            customerId: t.customerId,
            customerName: t.customerName,
            mobileNumber: t.mobileNumber || "",
            serviceName: t.serviceName || "General Service",
            applicationNumber: t.applicationNumber || null,
            currentStep: t.currentStep || "Application Received",
            status: t.status || "In Progress",
            progressPercent: t.progressPercent || 20,
            steps: t.steps || [],
            priority: t.priority || "Normal",
            targetDate: t.targetDate || null,
            assignedStaff: t.assignedStaff || null,
            paymentType: t.paymentType || "Cash",
            amountPaid: t.amountPaid || 0,
            amountPending: t.amountPending || 0,
            notes: t.notes || null
          });
          restoredCounts.applicationTasks++;
        }
      }
    }

    // Restore Enquiries
    if (Array.isArray(payload.enquiries) && payload.enquiries.length > 0) {
      for (const e of payload.enquiries) {
        if (e.customerName && e.mobileNumber) {
          await db.insert(enquiriesTable).values({
            customerId: e.customerId || `AN-${Math.floor(10000 + Math.random() * 90000)}`,
            customerName: e.customerName,
            mobileNumber: e.mobileNumber,
            serviceId: e.serviceId || null,
            applicationStatus: e.applicationStatus || "New",
            amountCharged: e.amountCharged || 0,
            amountPaid: e.amountPaid || 0,
            amountPending: e.amountPending || 0,
            paymentMethod: e.paymentMethod || "Pending",
            notes: e.notes || null
          });
          restoredCounts.enquiries++;
        }
      }
    }

    res.json({
      success: true,
      message: "Data restored successfully into database.",
      restoredCounts
    });
  } catch (error) {
    console.error("Error restoring backup:", error);
    res.status(500).json({ error: "Failed to restore backup data" });
  }
});

// 3. Purge / Cleanup Endpoint with Safety Verification
adminRouter.post("/backup/purge", async (req, res) => {
  try {
    const { target, confirmation } = req.body || {};

    if (confirmation !== "CONFIRM_DELETE") {
      res.status(400).json({ error: 'You must type "CONFIRM_DELETE" to authorize this operation' });
      return;
    }

    const { db, enquiriesTable, applicationTasksTable } = await import("@workspace/db");
    const { eq } = await import("drizzle-orm");

    let purgedCount = 0;

    if (target === "rejected_enquiries") {
      const result = await db.delete(enquiriesTable).where(eq(enquiriesTable.applicationStatus, "Rejected")).returning();
      purgedCount = result.length;
    } else if (target === "completed_enquiries") {
      const result = await db.delete(enquiriesTable).where(eq(enquiriesTable.applicationStatus, "Completed")).returning();
      purgedCount = result.length;
    } else if (target === "completed_tasks") {
      const result = await db.delete(applicationTasksTable).where(eq(applicationTasksTable.status, "Completed")).returning();
      purgedCount = result.length;
    } else {
      res.status(400).json({ error: "Invalid purge target specified" });
      return;
    }

    res.json({ success: true, purgedCount });
  } catch (error) {
    console.error("Error purging records:", error);
    res.status(500).json({ error: "Failed to purge selected records" });
  }
});

// ==========================================
// Reminders & Daily Reports Endpoints
// ==========================================

import {
  ensureReportTablesExist,
  calculateDailyReportMetrics,
  toISTDateString,
} from "../lib/daily-report-engine";
import { generateDailyReportPDF } from "../lib/pdf-report-generator";
import { getSMTPConfigInfo, sendTestEmail } from "../lib/daily-email-service";
import {
  computeNextScheduledTime,
  triggerDailyReportNow,
} from "../lib/daily-report-scheduler";

// 1. Get Settings & Delivery Status
adminRouter.get("/reports-daily/settings", async (req, res) => {
  try {
    const cached = getCache<any>("admin:report-settings");
    if (cached) {
      res.setHeader("X-Cache", "HIT");
      return res.json(cached);
    }

    const { getGmailIntegrationStatus } = await import("../lib/gmail-oauth-service");
    await ensureReportTablesExist();

    const [[settings], smtp, gmail] = await Promise.all([
      db.select().from(reportSettingsTable).where(eq(reportSettingsTable.id, "daily_report")),
      getSMTPConfigInfo(),
      getGmailIntegrationStatus(),
    ]);

    const currentSettings = settings || {
      id: "daily_report",
      adminEmail: "airnetcomputersbk@gmail.com",
      recipientEmail: "rasoolahmed246@gmail.com",
      autoEnabled: true,
      scheduledTime: "23:00",
      timeZone: "Asia/Kolkata",
      emailProvider: "gmail_api",
      lastRunDate: null,
      lastRunStatus: null,
      lastRunError: null,
    };

    const nextScheduled = computeNextScheduledTime(currentSettings.scheduledTime || "23:00");

    const payload = {
      settings: currentSettings,
      smtp,
      gmail,
      nextScheduled,
    };

    setCache("admin:report-settings", payload, 3600);
    res.setHeader("X-Cache", "MISS");
    res.json(payload);
  } catch (error) {
    console.error("Error fetching report settings:", error);
    res.status(500).json({ error: "Failed to fetch report settings" });
  }
});

// 2. Update Settings
adminRouter.post("/reports-daily/settings", async (req, res) => {
  try {
    await ensureReportTablesExist();

    const { adminEmail, recipientEmail, autoEnabled, scheduledTime, emailProvider } = req.body || {};

    // Validate admin email
    if (adminEmail && !adminEmail.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
      res.status(400).json({ error: "Please provide a valid admin email address" });
      return;
    }

    // Validate recipient email
    if (recipientEmail && !recipientEmail.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
      res.status(400).json({ error: "Please provide a valid recipient email address" });
      return;
    }

    // Validate scheduledTime format (HH:mm)
    if (scheduledTime && !scheduledTime.match(/^([01]\d|2[0-3]):([0-5]\d)$/)) {
      res.status(400).json({ error: "Scheduled time must be in 24-hour HH:mm format (e.g. 23:00)" });
      return;
    }

    const updatePayload: Record<string, any> = { updatedAt: new Date() };
    if (adminEmail !== undefined) updatePayload.adminEmail = adminEmail.trim();
    if (recipientEmail !== undefined) updatePayload.recipientEmail = recipientEmail.trim();
    if (autoEnabled !== undefined) updatePayload.autoEnabled = Boolean(autoEnabled);
    if (scheduledTime !== undefined) updatePayload.scheduledTime = scheduledTime.trim();
    if (emailProvider !== undefined && (emailProvider === "gmail_api" || emailProvider === "smtp")) {
      updatePayload.emailProvider = emailProvider;
    }

    await db
      .update(reportSettingsTable)
      .set(updatePayload)
      .where(eq(reportSettingsTable.id, "daily_report"));

    const [updated] = await db.select().from(reportSettingsTable).where(eq(reportSettingsTable.id, "daily_report"));
    const nextScheduled = computeNextScheduledTime(updated.scheduledTime);

    invalidateCache("admin:report-settings");
    broadcastEvent("settings", "update", updated);
    res.json({
      success: true,
      message: "Daily report settings updated successfully",
      settings: updated,
      nextScheduled,
    });
  } catch (error) {
    console.error("Error saving report settings:", error);
    res.status(500).json({ error: "Failed to save report settings" });
  }
});

// 3. Get Real Database Metrics for Report Date
adminRouter.get("/reports-daily/data", async (req, res) => {
  try {
    const targetDate = (req.query.date as string) || toISTDateString();
    const metrics = await calculateDailyReportMetrics(targetDate);
    res.json(metrics);
  } catch (error) {
    console.error("Error generating report metrics:", error);
    res.status(500).json({ error: "Failed to calculate report metrics" });
  }
});

// 4. Download / Stream Vector PDF
adminRouter.get("/reports-daily/pdf", async (req, res) => {
  try {
    const targetDate = (req.query.date as string) || toISTDateString();
    const metrics = await calculateDailyReportMetrics(targetDate);
    const pdfBuffer = await generateDailyReportPDF(metrics);

    const filename = `Airnet_Daily_Report_${targetDate}.pdf`;
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    res.setHeader("Content-Length", pdfBuffer.length);
    res.send(pdfBuffer);
  } catch (error) {
    console.error("Error generating report PDF:", error);
    res.status(500).json({ error: "Failed to generate report PDF" });
  }
});

// 5. Send Report Now (Manual Trigger)
adminRouter.post("/reports-daily/send-now", async (req, res) => {
  try {
    const { date, recipient, adminEmail } = req.body || {};
    const result = await triggerDailyReportNow(date, recipient, adminEmail);
    res.json(result);
  } catch (error) {
    console.error("Error sending daily report now:", error);
    res.status(500).json({ error: "Failed to dispatch daily report" });
  }
});

// 6. Send Test Email
adminRouter.post("/reports-daily/send-test", async (req, res) => {
  try {
    const { db, reportSettingsTable } = await import("@workspace/db");
    const { eq } = await import("drizzle-orm");
    await ensureReportTablesExist();

    const [settings] = await db.select().from(reportSettingsTable).where(eq(reportSettingsTable.id, "daily_report"));
    const targetEmail = req.body?.recipient || settings?.recipientEmail || "rasoolahmed246@gmail.com";
    const sourceAdmin = req.body?.adminEmail || settings?.adminEmail || "airnetcomputersbk@gmail.com";

    const testResult = await sendTestEmail(targetEmail, sourceAdmin);
    res.json(testResult);
  } catch (error) {
    console.error("Error sending test email:", error);
    res.status(500).json({ error: "Failed to execute test email" });
  }
});

// 7. Get Report Dispatch History
adminRouter.get("/reports-daily/history", async (req, res) => {
  try {
    const { db, dailyReportLogsTable } = await import("@workspace/db");
    const { desc } = await import("drizzle-orm");
    await ensureReportTablesExist();

    const logs = await db
      .select()
      .from(dailyReportLogsTable)
      .orderBy(desc(dailyReportLogsTable.generatedAt))
      .limit(50);

    res.json(logs);
  } catch (error) {
    console.error("Error fetching report history:", error);
    res.status(500).json({ error: "Failed to fetch report history logs" });
  }
});

// 8. Update / Verify SMTP Credentials
adminRouter.post("/reports-daily/smtp-config", async (req, res) => {
  try {
    const { updateSmtpSettings } = await import("../lib/daily-email-service");
    const result = await updateSmtpSettings(req.body || {});
    res.json(result);
  } catch (error: any) {
    console.error("Error updating SMTP config:", error);
    res.status(500).json({ success: false, message: error.message || "Failed to update SMTP settings" });
  }
});

// ==============================================================
// GMAIL API (OAUTH 2.0) INTEGRATION ENDPOINTS
// ==============================================================

// 9. Get current Gmail OAuth status & configuration (safe, no secrets)
adminRouter.get("/gmail/status", async (req, res) => {
  try {
    const { getGmailIntegrationStatus } = await import("../lib/gmail-oauth-service");
    const status = await getGmailIntegrationStatus();
    res.json(status);
  } catch (error: any) {
    console.error("Error fetching Gmail status:", error);
    res.status(500).json({ error: error.message || "Failed to fetch Gmail status" });
  }
});

// 10. Save / update Google Cloud OAuth Client ID & Client Secret (stored securely with AES-256-GCM)
adminRouter.post("/gmail/config", async (req, res) => {
  try {
    const { clientId, clientSecret } = req.body || {};
    if (!clientId || !clientSecret) {
      res.status(400).json({ error: "Both Client ID and Client Secret are required" });
      return;
    }

    const { saveGmailAppCredentials, getGmailIntegrationStatus } = await import("../lib/gmail-oauth-service");
    await saveGmailAppCredentials(clientId, clientSecret);
    const status = await getGmailIntegrationStatus();

    res.json({
      success: true,
      message: "Google OAuth credentials saved securely",
      status,
    });
  } catch (error: any) {
    console.error("Error saving Gmail OAuth credentials:", error);
    res.status(500).json({ error: error.message || "Failed to save OAuth credentials" });
  }
});

// 11. Generate Google OAuth 2.0 consent URL
adminRouter.get("/gmail/auth-url", async (req, res) => {
  try {
    const { generateGoogleAuthUrl } = await import("../lib/gmail-oauth-service");
    const origin = `${req.protocol}://${req.get("host")}`;
    const result = await generateGoogleAuthUrl(origin);
    res.json(result);
  } catch (error: any) {
    console.error("Error generating Google Auth URL:", error);
    res.status(400).json({ error: error.message || "Failed to generate authorization URL" });
  }
});

// 12. Disconnect Gmail Account (revokes tokens and removes from DB)
adminRouter.post("/gmail/disconnect", async (req, res) => {
  try {
    const { disconnectGmailAccount, getGmailIntegrationStatus } = await import("../lib/gmail-oauth-service");
    const result = await disconnectGmailAccount();
    const status = await getGmailIntegrationStatus();

    res.json({
      success: true,
      message: result.message,
      status,
    });
  } catch (error: any) {
    console.error("Error disconnecting Gmail account:", error);
    res.status(500).json({ error: error.message || "Failed to disconnect Gmail account" });
  }
});

// 14. Send Test Email using official Gmail API
adminRouter.post("/gmail/test-email", async (req, res) => {
  try {
    const { sendTestEmail } = await import("../lib/daily-email-service");
    const { db, reportSettingsTable } = await import("@workspace/db");
    const { eq } = await import("drizzle-orm");
    await ensureReportTablesExist();

    const [settings] = await db.select().from(reportSettingsTable).where(eq(reportSettingsTable.id, "daily_report"));
    const targetEmail = req.body?.recipient || settings?.recipientEmail || "rasoolahmed246@gmail.com";
    const sourceAdmin = req.body?.adminEmail || settings?.adminEmail || "airnetcomputersbk@gmail.com";

    const testResult = await sendTestEmail(targetEmail, sourceAdmin);
    res.json(testResult);
  } catch (error: any) {
    console.error("Error sending Gmail test email:", error);
    res.status(500).json({ error: error.message || "Failed to send Gmail test email" });
  }
});

// ==========================================
// 15. ADMIN SETTINGS & SECURITY MANAGEMENT
// ==========================================

// Get Admin Profile & Security Configuration
adminRouter.get("/settings", async (req, res) => {
  try {
    const cached = getCache<any>("admin:settings");
    if (cached) {
      res.setHeader("X-Cache", "HIT");
      return res.json(cached);
    }

    const { CONSTANT_ADMIN_EMAIL, getMobileSettingsInfo } = await import("../lib/admin-auth-service");
    const { db, reportSettingsTable } = await import("@workspace/db");
    const { eq } = await import("drizzle-orm");
    await ensureReportTablesExist();

    const [settings] = await db
      .select()
      .from(reportSettingsTable)
      .where(eq(reportSettingsTable.id, "daily_report"));

    const mobileInfo = await getMobileSettingsInfo();

    const responsePayload = {
      adminEmail: CONSTANT_ADMIN_EMAIL,
      isConstantEmail: true,
      passwordUpdatedAt: settings?.adminPasswordUpdatedAt || null,
      lastOtpSentAt: settings?.adminResetOtpExpiry
        ? new Date(new Date(settings.adminResetOtpExpiry).getTime() - 10 * 60 * 1000)
        : null,
      supportPhone: mobileInfo.adminMobileNumber,
      adminMobileNumber: mobileInfo.adminMobileNumber,
      frontendMobileNumber: mobileInfo.frontendMobileNumber,
      showUpdatedMobileOnFrontend: mobileInfo.showUpdatedMobileOnFrontend,
      effectiveFrontendNumber: mobileInfo.effectiveFrontendNumber,
      organization: "Airnet Computers",
      location: "Basavakalyan - 585327",
    };

    setCache("admin:settings", responsePayload, 3600);
    res.setHeader("X-Cache", "MISS");
    res.json(responsePayload);
  } catch (err: any) {
    console.error("Error fetching admin settings:", err);
    res.status(500).json({ error: err.message || "Failed to fetch admin settings" });
  }
});

// Change Admin Password directly
adminRouter.post("/settings/change-password", async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const { changeAdminPasswordDirect } = await import("../lib/admin-auth-service");
    const result = await changeAdminPasswordDirect(currentPassword, newPassword);

    if (result.success) {
      invalidateCache("admin:settings");
      res.cookie("admin_session", newPassword, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        maxAge: 1000 * 60 * 60 * 24, // 24 hours
      });
    }

    res.json(result);
  } catch (err: any) {
    console.error("Error changing admin password:", err);
    res.status(500).json({ success: false, message: err.message || "Failed to change admin password" });
  }
});

// Send Test OTP to constant admin email
adminRouter.post("/settings/send-test-otp", async (req, res) => {
  try {
    const { generateAndSendAdminOtp } = await import("../lib/admin-auth-service");
    const result = await generateAndSendAdminOtp();
    res.json(result);
  } catch (err: any) {
    console.error("Error sending test OTP:", err);
    res.status(500).json({ success: false, message: err.message || "Failed to send test OTP" });
  }
});

// Request OTP to change official admin mobile number
adminRouter.post("/settings/request-mobile-otp", async (req, res) => {
  try {
    const { newMobileNumber } = req.body;
    const { sendMobileChangeOtp } = await import("../lib/admin-auth-service");
    const result = await sendMobileChangeOtp(newMobileNumber);
    res.json(result);
  } catch (err: any) {
    console.error("Error requesting mobile change OTP:", err);
    res.status(500).json({ success: false, message: err.message || "Failed to request mobile change OTP" });
  }
});

// Verify OTP and update official admin mobile number
adminRouter.post("/settings/verify-mobile-otp", async (req, res) => {
  try {
    const { otp } = req.body;
    const { verifyAndApplyMobileChange } = await import("../lib/admin-auth-service");
    const result = await verifyAndApplyMobileChange(otp);
    if (!result.success) {
      res.status(400).json(result);
      return;
    }
    invalidateCache("admin:settings", "business-info");
    res.json(result);
  } catch (err: any) {
    console.error("Error verifying mobile change OTP:", err);
    res.status(500).json({ success: false, message: err.message || "Failed to verify mobile change OTP" });
  }
});

// Grant or revoke permission to display the updated mobile number on public frontend
adminRouter.post("/settings/frontend-mobile-permission", async (req, res) => {
  try {
    const { grantPermission } = req.body;
    const { setFrontendMobilePermission } = await import("../lib/admin-auth-service");
    const result = await setFrontendMobilePermission(Boolean(grantPermission));
    invalidateCache("admin:settings", "business-info");
    res.json(result);
  } catch (err: any) {
    console.error("Error updating frontend mobile permission:", err);
    res.status(500).json({ success: false, message: err.message || "Failed to update frontend mobile permission" });
  }
});

// =========================================================================
// AI-POWERED RECOMMENDATION SYSTEM ENDPOINTS
// =========================================================================

// 1. Get all AI recommendations with current statuses & summary metrics
adminRouter.get("/ai-suggestions", async (req, res) => {
  try {
    const { reanalyzeSystem } = await import("../lib/ai-recommendations-service");
    const data = reanalyzeSystem();
    res.json(data);
  } catch (err: any) {
    console.error("Error fetching AI suggestions:", err);
    res.status(500).json({ error: "Failed to fetch AI suggestions" });
  }
});

// 2. Perform user action on a recommendation (approve / reject / reset)
adminRouter.post("/ai-suggestions/action", async (req, res) => {
  try {
    const { id, action } = req.body || {};
    if (!id || !["approve", "reject", "reset"].includes(action)) {
      res.status(400).json({ error: "Valid 'id' and 'action' ('approve' | 'reject' | 'reset') required" });
      return;
    }
    const { updateRecommendationStatus } = await import("../lib/ai-recommendations-service");
    const result = updateRecommendationStatus(id, action);
    if (!result.success) {
      res.status(404).json(result);
      return;
    }
    res.json(result);
  } catch (err: any) {
    console.error("Error updating AI suggestion action:", err);
    res.status(500).json({ error: "Failed to update AI suggestion status" });
  }
});

// 3. Trigger manual AI re-analysis of the application
adminRouter.post("/ai-suggestions/reanalyze", async (req, res) => {
  try {
    const { reanalyzeSystem } = await import("../lib/ai-recommendations-service");
    const data = reanalyzeSystem();
    res.json({
      success: true,
      message: "AI re-analysis completed successfully",
      ...data,
    });
  } catch (err: any) {
    console.error("Error running AI re-analysis:", err);
    res.status(500).json({ error: "Failed to run AI re-analysis" });
  }
});




