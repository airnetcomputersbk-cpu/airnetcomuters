import { StrictMode, lazy, Suspense } from 'react';
import { createRoot } from 'react-dom/client';
import { Switch, Route } from "wouter";
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import App from './App.tsx';
import { ModalProvider } from './context/ModalContext.tsx';
import './index.css';

const AdminLayout = lazy(() => import('./pages/admin/Layout.tsx'));

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 30, // 30 seconds
      refetchOnWindowFocus: false,
    },
  },
});

function AdminFallback() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#061e38]">
      <div className="flex flex-col items-center gap-3">
        <div className="w-10 h-10 border-3 border-blue-500 border-t-transparent rounded-full animate-spin" />
        <span className="text-xs font-semibold text-blue-200 tracking-wider uppercase">Loading Admin Workspace...</span>
      </div>
    </div>
  );
}

function Root() {
  return (
    <QueryClientProvider client={queryClient}>
      <ModalProvider>
        <Suspense fallback={<AdminFallback />}>
          <Switch>
            <Route path="/admin/*" component={AdminLayout} />
            <Route path="*" component={App} />
          </Switch>
        </Suspense>
      </ModalProvider>
    </QueryClientProvider>
  );
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <Root />
  </StrictMode>
);
