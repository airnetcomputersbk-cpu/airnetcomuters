import fs from "fs";
import path from "path";
import { execSync } from "child_process";

console.log("Generating clean, ultra-lightweight deployment zip...");

const targetZip = path.resolve(process.cwd(), "airnet-deploy.zip");
if (fs.existsSync(targetZip)) {
  fs.unlinkSync(targetZip);
}

// Explicit list of directories and files to pack
const itemsToInclude = [
  "artifacts",
  "lib",
  "scripts",
  "data",
  "package.json",
  "pnpm-lock.yaml",
  "pnpm-workspace.yaml",
  "tsconfig.json",
  ".env",
];

const pathsString = itemsToInclude
  .filter((item) => fs.existsSync(path.resolve(process.cwd(), item)))
  .map((item) => `'${item}'`)
  .join(", ");

const psCmd = `Compress-Archive -Path ${pathsString} -DestinationPath '${targetZip}' -Force`;

try {
  execSync(`powershell -NoProfile -Command "${psCmd}"`, { stdio: "inherit" });
  const stats = fs.statSync(targetZip);
  const sizeMB = (stats.size / (1024 * 1024)).toFixed(2);
  console.log(`\nSUCCESS! Created: ${targetZip}`);
  console.log(`Package Size: ${sizeMB} MB (Ultra-lightweight! Uploads in < 30 seconds)`);
} catch (err) {
  console.error("Error creating zip:", err);
}
